@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALAR_MENUX_PRINT.ps1"
echo.
echo Veja as mensagens acima.
pause
