$ErrorActionPreference = 'Stop'
$base = Join-Path $env:LOCALAPPDATA 'MENUX\impressor'
$script = Join-Path $base 'menux-impressor-windows.py'
$startup = [Environment]::GetFolderPath('Startup')
$link = Join-Path $startup 'MENUX Print.lnk'
Write-Host 'MENUX PRINT - DESINSTALACAO' -ForegroundColor Cyan
Write-Host 'Esta operacao remove o MENUX Print deste usuario do Windows.'
Write-Host 'Serao apagados a chave local, historico de impressoes e logs.'
Write-Host 'Python, impressoras, pedidos e dados online NAO serao removidos.'
$confirm = Read-Host 'Para confirmar, digite DESINSTALAR'
if ($confirm -cne 'DESINSTALAR') { Write-Host 'Cancelado. Nenhuma alteracao realizada.'; exit 0 }
# Remove somente o atalho do MENUX Print que aponta para a instalacao deste usuario.
if (Test-Path -LiteralPath $link) {
  $wsh = New-Object -ComObject WScript.Shell
  $shortcut = $wsh.CreateShortcut($link)
  $args = [string]$shortcut.Arguments
  if ($args.IndexOf($base, [StringComparison]::OrdinalIgnoreCase) -ge 0) {
    Remove-Item -LiteralPath $link -Force
    Write-Host 'Inicializacao automatica removida.'
  } else {
    Write-Warning 'Atalho com destino diferente encontrado; foi preservado.'
  }
}
# Encerra exclusivamente processos Python que executam o script desta instalacao.
$processes = @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
  $_.Name -match '^(python|pythonw|py|pyw)(\.exe)?$' -and
  $_.CommandLine -and
  $_.CommandLine.IndexOf($script, [StringComparison]::OrdinalIgnoreCase) -ge 0
})
foreach ($proc in $processes) {
  try {
    Stop-Process -Id $proc.ProcessId -Force -ErrorAction Stop
    Write-Host ('Processo MENUX Print encerrado: '+$proc.ProcessId)
  } catch { Write-Warning ('Nao foi possivel encerrar o processo '+$proc.ProcessId+': '+$_.Exception.Message) }
}
Start-Sleep -Milliseconds 800
if (Test-Path -LiteralPath $base) {
  Remove-Item -LiteralPath $base -Recurse -Force -ErrorAction Stop
  Write-Host 'Arquivos e configuracoes locais removidos.'
}
Write-Host 'MENUX Print desinstalado deste usuario com sucesso.' -ForegroundColor Green
