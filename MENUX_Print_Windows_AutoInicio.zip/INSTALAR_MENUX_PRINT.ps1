﻿$ErrorActionPreference = 'Stop'
$base = Join-Path $env:LOCALAPPDATA 'MENUX\impressor'
$source = Join-Path $PSScriptRoot 'menux-impressor-windows.py'
if (-not (Test-Path -LiteralPath $source)) { throw 'Extraia TODOS os arquivos do ZIP antes de instalar.' }
function Probe-Python([string]$exe,[string]$arguments) {
  try {
    $start=New-Object System.Diagnostics.ProcessStartInfo
    $start.FileName=$exe; $start.Arguments=($arguments+' -c "import sys;print(sys.executable)"').Trim()
    $start.UseShellExecute=$false; $start.RedirectStandardOutput=$true; $start.RedirectStandardError=$true
    $start.CreateNoWindow=$true
    $proc=[System.Diagnostics.Process]::Start($start)
    if(-not $proc.WaitForExit(12000)){try{$proc.Kill()}catch{};return $null}
    $result=$proc.StandardOutput.ReadToEnd().Trim()
    if($proc.ExitCode -eq 0 -and (Test-Path -LiteralPath $result)){ return $result }
  }catch{}
  return $null
}
$python=$null
foreach($entry in @(@('py.exe','-3'),@('python.exe',''),@('python3.exe',''))) {
  if(-not $python){$python=Probe-Python $entry[0] $entry[1]}
}
if(-not $python){ throw 'Python 3 nao encontrado ou sem interpretador instalado. Instale Python 3 de python.org, marque Add Python to PATH e tente novamente.' }
$pythonw=Join-Path (Split-Path -Parent $python) 'pythonw.exe'
$interpreter=if(Test-Path -LiteralPath $pythonw){$pythonw}else{$python}
# Confere sintaxe antes de substituir arquivos existentes.
$syntax= & $python -m py_compile $source 2>&1
if($LASTEXITCODE -ne 0){throw ('Codigo de impressao com erro: '+($syntax -join ' '))}
New-Item -ItemType Directory -Force -Path $base | Out-Null
# Para impedir que a versao anterior continue ouvindo na mesma porta.
Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
 $_.CommandLine -and $_.CommandLine.Contains('menux-impressor-windows.py') -and $_.Name -match '^pythonw?\.exe$|^pyw?\.exe$'
} | ForEach-Object {try {Stop-Process -Id $_.ProcessId -Force -ErrorAction Stop}catch {}}
Start-Sleep -Seconds 2
foreach($name in @('menux-impressor-windows.py','menux-imprimir-a4.ps1')) {
 Copy-Item -LiteralPath (Join-Path $PSScriptRoot $name) -Destination (Join-Path $base $name) -Force
}
$tokenFile=Join-Path $base 'chave.txt'
if(-not (Test-Path -LiteralPath $tokenFile)) {
 $buf=New-Object byte[] 32; $rng=[Security.Cryptography.RandomNumberGenerator]::Create()
 try{$rng.GetBytes($buf)}finally{$rng.Dispose()}
 $value=[Convert]::ToBase64String($buf).TrimEnd('=').Replace('+','-').Replace('/','_')
 [IO.File]::WriteAllText($tokenFile,$value,[Text.Encoding]::ASCII)
}
# VBS inicia pythonw (ou python) com a janela sempre oculta.
$vbsFile=Join-Path $base 'INICIAR_MENUX_PRINT_OCULTO.vbs'
$script=Join-Path $base 'menux-impressor-windows.py'
$exeEsc=$interpreter.Replace('"','""'); $scriptEsc=$script.Replace('"','""')
$vbs=@(
 'Set shell = CreateObject("WScript.Shell")',
 'shell.Run Chr(34) & "' + $exeEsc + '" & Chr(34) & " " & Chr(34) & "' + $scriptEsc + '" & Chr(34), 0, False'
)
[IO.File]::WriteAllLines($vbsFile,$vbs,[Text.Encoding]::ASCII)
$wscript=Join-Path $env:SystemRoot 'System32\wscript.exe'
$startup=[Environment]::GetFolderPath('Startup')
if(-not (Test-Path -LiteralPath $startup)){New-Item -ItemType Directory -Force -Path $startup | Out-Null}
$lnk=Join-Path $startup 'MENUX Print.lnk'
$wsh=New-Object -ComObject WScript.Shell
$shortcut=$wsh.CreateShortcut($lnk)
$shortcut.TargetPath=$wscript
$shortcut.Arguments='"'+$vbsFile+'"'
$shortcut.WorkingDirectory=$base
$shortcut.WindowStyle=7
$shortcut.Description='MENUX Print - inicializacao automatica oculta'
$shortcut.Save()
# Executa uma unica instancia agora, para nao precisar reiniciar para testar.
Start-Process -FilePath $wscript -ArgumentList ('"'+$vbsFile+'"') -WorkingDirectory $base -WindowStyle Hidden
Start-Sleep -Seconds 3
$listen=Get-NetTCPConnection -LocalPort 18774 -State Listen -ErrorAction SilentlyContinue
if(-not $listen) {
 Write-Warning ('MENUX Print instalado, mas nao iniciou. Confira o log em '+(Join-Path $base 'menux-print.log'))
 Write-Host 'A inicializacao no Windows foi configurada; nao considere a impressao ativa ate o teste de conexao.' -ForegroundColor Yellow
}else{
 Write-Host 'MENUX Print ATIVO e configurado para iniciar automaticamente ao entrar no Windows.' -ForegroundColor Green
}
Write-Host 'Programa instalado em:' $base
Write-Host 'Para ver a chave local no futuro, abra o arquivo chave.txt na pasta de instalacao.'
Write-Host 'ATENCAO: mantenha a chave em sigilo. Nao precisa colar novamente no painel se ja esta salva.'
