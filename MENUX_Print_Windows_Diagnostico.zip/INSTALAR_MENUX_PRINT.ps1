﻿$ErrorActionPreference = 'Stop'
$base = Join-Path $env:LOCALAPPDATA 'MENUX\impressor'
$pyScript = Join-Path $base 'menux-impressor-windows.py'
$source = Join-Path $PSScriptRoot 'menux-impressor-windows.py'
if (-not (Test-Path -LiteralPath $source)) { throw 'Arquivo menux-impressor-windows.py nao encontrado. Extraia o ZIP inteiro antes de instalar.' }

# Resolve o Python sem executar py -3 diretamente no PowerShell (pode produzir NativeCommandError).
function Run-PythonProbe([string]$exe, [string]$prefix) {
    try {
        $p = New-Object System.Diagnostics.Process
        $p.StartInfo.FileName = $exe
        $p.StartInfo.Arguments = ($prefix + ' -c "import sys;print(sys.executable)"').Trim()
        $p.StartInfo.UseShellExecute = $false
        $p.StartInfo.RedirectStandardOutput = $true
        $p.StartInfo.RedirectStandardError = $true
        $p.StartInfo.CreateNoWindow = $true
        [void]$p.Start()
        $value = $p.StandardOutput.ReadToEnd().Trim()
        $err = $p.StandardError.ReadToEnd().Trim()
        $p.WaitForExit(10000) | Out-Null
        if ($p.ExitCode -eq 0 -and (Test-Path -LiteralPath $value)) { return $value }
    } catch { }
    return $null
}
$python = $null
if (Get-Command py.exe -ErrorAction SilentlyContinue) { $python = Run-PythonProbe 'py.exe' '-3' }
if (-not $python -and (Get-Command python.exe -ErrorAction SilentlyContinue)) { $python = Run-PythonProbe 'python.exe' '' }
if (-not $python) { throw 'Python 3 nao encontrado. Instale o Python 3 para Windows e execute este instalador novamente.' }
$pythonw = Join-Path (Split-Path -Parent $python) 'pythonw.exe'
# Se o Python for da Microsoft Store, pythonw pode nao estar no mesmo diretorio.
if (-not (Test-Path -LiteralPath $pythonw)) {
    $where = Get-Command pythonw.exe -ErrorAction SilentlyContinue
    if ($where -and (Test-Path -LiteralPath $where.Source)) { $pythonw=$where.Source }
}

New-Item -ItemType Directory -Force -Path $base | Out-Null
# Encerra somente o impressor MENUX anterior, para nao deixar a porta 18774 ocupada.
Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
    $_.CommandLine -and $_.CommandLine.Contains('menux-impressor-windows.py') -and
    ($_.Name -match '^pythonw?\.exe$|^pyw?\.exe$')
} | ForEach-Object {
    try { Stop-Process -Id $_.ProcessId -Force -ErrorAction Stop } catch { }
}
Start-Sleep -Seconds 1
foreach ($file in @('menux-impressor-windows.py','menux-imprimir-a4.ps1')) {
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot $file) -Destination (Join-Path $base $file) -Force
}
$tokenFile = Join-Path $base 'chave.txt'
# Preserve a chave local antiga, caso exista; nunca substitua sem necessidade.
if (-not (Test-Path -LiteralPath $tokenFile)) {
    $bytes = New-Object byte[] 32
    $rng=[System.Security.Cryptography.RandomNumberGenerator]::Create()
    try {$rng.GetBytes($bytes)} finally {$rng.Dispose()}
    $token=[Convert]::ToBase64String($bytes).TrimEnd('=').Replace('+','-').Replace('/','_')
    [System.IO.File]::WriteAllText($tokenFile,$token,[System.Text.Encoding]::ASCII)
}
$token=[System.IO.File]::ReadAllText($tokenFile).Trim()

# Se pythonw nao existir, inicia python.exe invisivelmente por um script VBS.
$launcher=$pythonw
$args='"'+$pyScript+'"'
if (-not (Test-Path -LiteralPath $pythonw)) {
    $vbs=Join-Path $base 'iniciar-oculto.vbs'
    $escapedPython=$python.Replace('"','""')
    $escapedScript=$pyScript.Replace('"','""')
    $vbsLines=@(
        'Set shell = CreateObject("WScript.Shell")',
        'shell.Run Chr(34) & "' + $escapedPython + '" & Chr(34) & " " & Chr(34) & "' + $escapedScript + '" & Chr(34), 0, False'
    )
    [System.IO.File]::WriteAllLines($vbs,$vbsLines,[System.Text.Encoding]::ASCII)
    $launcher=Join-Path $env:SystemRoot 'System32\wscript.exe'
    $args='"'+$vbs+'"'
}
$startup=[Environment]::GetFolderPath('Startup')
$shortcutPath=Join-Path $startup 'MENUX Print.lnk'
$wsh=New-Object -ComObject WScript.Shell
$link=$wsh.CreateShortcut($shortcutPath)
$link.TargetPath=$launcher
$link.Arguments=$args
$link.WorkingDirectory=$base
$link.WindowStyle=7
$link.Description='MENUX Print - comanda automatica, sem janela'
$link.Save()
Start-Process -FilePath $launcher -ArgumentList $args -WorkingDirectory $base -WindowStyle Hidden
Start-Sleep -Seconds 2
$listen = Get-NetTCPConnection -LocalPort 18774 -State Listen -ErrorAction SilentlyContinue
if (-not $listen) {
    Write-Warning 'Programa instalado, mas a conexao local nao respondeu. Consulte menux-print.log na pasta LocalAppData\MENUX\impressor.'
} else {
    Write-Host 'MENUX Print iniciou corretamente na porta 18774.' -ForegroundColor Green
}
Write-Host 'Instalacao concluida. Python encontrado: ' $python
Write-Host 'A chave abaixo e local: nao compartilhe com outras pessoas.'
Write-Host $token
Write-Host 'Abra a aba Impressao no painel da MENUX e selecione A4 para a Epson L395.'
