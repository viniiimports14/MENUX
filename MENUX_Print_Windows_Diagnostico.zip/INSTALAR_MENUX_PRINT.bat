@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALAR_MENUX_PRINT.ps1"
if errorlevel 1 (
 echo.
 echo Instalacao falhou. Leia a mensagem acima.
)
echo.
pause
