@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALAR_MENUX_PRINT.ps1"
echo.
pause
