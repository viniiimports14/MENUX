﻿$ErrorActionPreference='Stop'
$base = Join-Path $env:LOCALAPPDATA 'MENUX\impressor'
New-Item -ItemType Directory -Force -Path $base | Out-Null
foreach($file in @('menux-impressor-windows.py','menux-imprimir-a4.ps1')){
 Copy-Item -LiteralPath (Join-Path $PSScriptRoot $file) -Destination (Join-Path $base $file) -Force
}
$pythonw = (& py -3 -c 'import sys,os;print(os.path.join(os.path.dirname(sys.executable),"pythonw.exe"))' 2>$null)
if (-not $pythonw -or -not (Test-Path $pythonw)) {
 $pythonw = (Get-Command pythonw.exe -ErrorAction SilentlyContinue).Source
}
if (-not $pythonw -or -not (Test-Path $pythonw)) {throw 'Instale Python 3 antes de continuar: https://www.python.org/downloads/windows/'}
$tokenFile = Join-Path $base 'chave.txt'
if(-not (Test-Path $tokenFile)){
 $rng = [Security.Cryptography.RandomNumberGenerator]::Create()
 $bytes = New-Object byte[] 32
 try {$rng.GetBytes($bytes)} finally {$rng.Dispose()}
 $newToken = [Convert]::ToBase64String($bytes).TrimEnd('=').Replace('+','-').Replace('/','_')
 [IO.File]::WriteAllText($tokenFile,$newToken,[Text.Encoding]::ASCII)
}
$token = [IO.File]::ReadAllText($tokenFile,[Text.Encoding]::ASCII).Trim()
Write-Host 'CHAVE PARA CONECTAR NO PAINEL MENUX (guarde em local seguro):'
Write-Host $token
Write-Host ''
$startup = [Environment]::GetFolderPath('Startup')
$shortcutPath = Join-Path $startup 'MENUX Print.lnk'
$wsh = New-Object -ComObject WScript.Shell
$link = $wsh.CreateShortcut($shortcutPath)
$link.TargetPath = $pythonw
$link.Arguments = '"' + (Join-Path $base 'menux-impressor-windows.py') + '"'
$link.WorkingDirectory = $base
$link.WindowStyle = 7
$link.Description = 'MENUX Print - impressao local em segundo plano'
$link.Save()
# Inicia sem janela imediatamente; reiniciar o Windows nao exige executar o instalador.
$active = Get-NetTCPConnection -LocalPort 18774 -State Listen -ErrorAction SilentlyContinue
if(-not $active){Start-Process -FilePath $pythonw -ArgumentList ('"'+(Join-Path $base 'menux-impressor-windows.py')+'"') -WorkingDirectory $base -WindowStyle Hidden}
Write-Host 'Instalacao concluida. MENUX Print inicia quando voce entra no Windows.'
Write-Host 'O painel MENUX ainda precisa estar aberto para encaminhar novos pedidos.'
