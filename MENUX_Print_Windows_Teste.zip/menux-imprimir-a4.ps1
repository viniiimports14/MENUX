﻿param([Parameter(Mandatory=$true)][string]$TicketPath,[Parameter(Mandatory=$true)][string]$PrinterName)
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Drawing
$data = Get-Content -LiteralPath $TicketPath -Raw -Encoding UTF8 | ConvertFrom-Json
$lines = @($data.lines)
$doc = New-Object System.Drawing.Printing.PrintDocument
$doc.PrinterSettings.PrinterName = $PrinterName
if (-not $doc.PrinterSettings.IsValid) { throw "Impressora nao disponivel: $PrinterName" }
$size = $doc.PrinterSettings.PaperSizes | Where-Object { $_.Kind -eq [System.Drawing.Printing.PaperKind]::A4 } | Select-Object -First 1
if (-not $size) { throw 'O driver da impressora nao disponibilizou o papel A4.' }
$doc.DefaultPageSettings.PaperSize = $size
$doc.DefaultPageSettings.Margins = New-Object System.Drawing.Printing.Margins(55,55,55,55)
$doc.PrintController = New-Object System.Drawing.Printing.StandardPrintController
$font = New-Object System.Drawing.Font('Consolas',10,[System.Drawing.FontStyle]::Regular)
$brush = [System.Drawing.Brushes]::Black
$script:menuxIndex=0
$format = New-Object System.Drawing.StringFormat
$format.Trimming = [System.Drawing.StringTrimming]::None
$format.FormatFlags = [System.Drawing.StringFormatFlags]::LineLimit
$handler = [System.Drawing.Printing.PrintPageEventHandler]{
 param($sender,$e)
 # Intersecao entre margem solicitada e regiao efetivamente imprimivel do driver.
 $bounds=$e.MarginBounds
 $printable=$e.PageSettings.PrintableArea
 $left=[single][Math]::Max($bounds.Left, $printable.Left + 8)
 $top=[single][Math]::Max($bounds.Top, $printable.Top + 8)
 $right=[single][Math]::Min($bounds.Right, $printable.Right - 8)
 $bottom=[single][Math]::Min($bounds.Bottom, $printable.Bottom - 8)
 if($right -le $left -or $bottom -le $top){throw 'Area util da impressora invalida. Confira margens e tamanho A4 no driver.'}
 $y=$top
 $lineHeight=[single]($font.GetHeight($e.Graphics)*1.35)
 while($script:menuxIndex -lt $lines.Length){
   $line=[string]$lines[$script:menuxIndex]
   $size=$e.Graphics.MeasureString($line,$font,[int]($right-$left),$format)
   $height=[single][Math]::Max($lineHeight,$size.Height+3)
   if($y+$height -gt $bottom){$e.HasMorePages=$true;return}
   $rect=New-Object System.Drawing.RectangleF($left,$y,[single]($right-$left),$height)
   $e.Graphics.DrawString($line,$font,$brush,$rect,$format)
   $y += $height
   $script:menuxIndex++
 }
 $e.HasMorePages=$false
}
$doc.add_PrintPage($handler)
try{$doc.Print()}finally{$doc.remove_PrintPage($handler);$font.Dispose();$format.Dispose();$doc.Dispose()}
