# MENUX - impressor local gratuito Windows (Python 3, biblioteca padrao)
# Mantem a impressora sob controle do computador do estabelecimento.
# Nunca informe este token a terceiros; o programa aceita somente requests da origem da MENUX.
import base64, ctypes, ctypes.wintypes as wt, http.server, json, os, pathlib, secrets, sqlite3, subprocess, sys, textwrap, threading, time
from urllib.parse import urlsplit

if os.name != 'nt':
    print('Este programa e exclusivo para Windows 10/11.'); sys.exit(1)
HOME = pathlib.Path(os.environ.get('LOCALAPPDATA', str(pathlib.Path.home()))) / 'MENUX' / 'impressor'
HOME.mkdir(parents=True, exist_ok=True)
TOKEN_FILE=HOME/'chave.txt'; DB_PATH=HOME/'comandas.sqlite3'; PORT=18774
ORIGIN='https://viniiimports14.github.io'
if not TOKEN_FILE.exists(): TOKEN_FILE.write_text(secrets.token_urlsafe(32), encoding='ascii')
TOKEN=TOKEN_FILE.read_text(encoding='ascii').strip()
DATABASE=sqlite3.connect(str(DB_PATH),check_same_thread=False)
DATABASE.execute('CREATE TABLE IF NOT EXISTS prints (restaurant TEXT NOT NULL, order_id TEXT NOT NULL, printed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(restaurant,order_id))')
DATABASE.commit()
LOCK=threading.Lock()

# Usa drivers instalados no Windows. Imprime texto como RAW ESC/POS; o modelo deve oferecer modo ESC/POS.
def installed_printers():
    script="[Console]::OutputEncoding=[Text.Encoding]::UTF8; Get-CimInstance Win32_Printer | Select-Object -ExpandProperty Name"
    p=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command',script],capture_output=True,text=True,encoding='utf-8',timeout=15,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    if p.returncode: raise RuntimeError(p.stderr.strip()[:250] or 'Nao foi possivel listar impressoras')
    return [x.strip() for x in p.stdout.splitlines() if x.strip()]

def clean(v):
    return ''.join(c if ord(c)>=32 and c not in '\x7f' else ' ' for c in str(v or ''))
def fmtmoney(v):
    try: return 'R$ '+f'{float(v):,.2f}'.replace(',','!').replace('.',',').replace('!','.')
    except (TypeError,ValueError): return 'R$ 0,00'
def wrap(value, cols):
    return textwrap.wrap(clean(value),width=cols,break_long_words=True,break_on_hyphens=False) or ['']
def build_ticket(order, items, width, as_lines=False):
    # Reduz a largura util para reservar margens de seguranca em ambos os lados.
    # 58 mm: 26 colunas + 2 espacos de margem esquerda; 80 mm: 40 + 2.
    # A4 e renderizado pelo driver do Windows, com quebra pela area de impressao.
    cols=26 if width==58 else (40 if width==80 else 70)
    lines=[]
    def add(txt=''):
        for line in wrap(txt,cols): lines.append(line)
    def div(): lines.append('-'*cols)
    name=clean(order.get('store_name') or 'MENUX')
    add(name.upper()); add('PEDIDO #'+str(order.get('daily_number') or '').zfill(3)); div()
    mode={'delivery':'ENTREGA','pickup':'RETIRADA','table':'MESA'}.get(order.get('fulfillment'),'PEDIDO')
    add(mode+(' '+clean(order.get('table_number')) if mode=='MESA' else ''))
    add('Cliente: '+clean(order.get('customer_name')))
    add('Telefone: '+clean(order.get('customer_phone')))
    if mode=='ENTREGA':
        add('Regiao: '+clean(order.get('delivery_area_name')))
        add('Endereco: '+clean(order.get('delivery_address')))
    div(); add('ITENS PARA PREPARAR')
    for item in items:
        add(str(item.get('quantity') or 1)+'x '+clean(item.get('product_name')))
        for opt in (item.get('options') if isinstance(item.get('options'),list) else []):
            if isinstance(opt,dict): add('  + '+clean(opt.get('name'))+(' ('+fmtmoney(opt.get('price'))+')' if float(opt.get('price') or 0)>0 else ''))
        add('  '+fmtmoney(float(item.get('unit_price') or 0)*int(item.get('quantity') or 1)))
        div()
    add('Observacoes: '+clean(order.get('notes') or 'Nenhuma'))
    add('Produtos: '+fmtmoney(order.get('subtotal')))
    if mode=='ENTREGA':add('Entrega: '+fmtmoney(order.get('delivery_fee')))
    add('TOTAL: '+fmtmoney(order.get('total')))
    payment={'pix':'PIX','cash':'Dinheiro','credit_card':'Credito','debit_card':'Debito'}.get(order.get('payment_method'),'Nao informado')
    add('Pagamento: '+payment)
    add('AGUARDANDO ACEITE' if order.get('status')=='pending' else 'Status: '+clean(order.get('status')))
    add('');add('MENUX - COMANDA');add('');add('')
    if as_lines:return lines
    # Pequeno recuo em todas as linhas, incluindo separadores, para evitar
    # que as letras comecem no limite fisico do cabecote termico.
    lines=['  '+line for line in lines]
    # CP850 e ESC/POS sao comuns em impressoras termicas, mas precisam de teste no modelo.
    return b'\x1b@\x1bt\x02'+ ('\n'.join(lines)+'\n\n\n').encode('cp850','replace') + b'\x1dV\x00'

def raw_print(printer, raw, job_name):
    spool=ctypes.WinDLL('winspool.drv',use_last_error=True)
    handle=wt.HANDLE()
    spool.OpenPrinterW.argtypes=[wt.LPWSTR,ctypes.POINTER(wt.HANDLE),ctypes.c_void_p]; spool.OpenPrinterW.restype=wt.BOOL
    spool.StartDocPrinterW.argtypes=[wt.HANDLE,wt.DWORD,ctypes.c_void_p]; spool.StartDocPrinterW.restype=wt.DWORD
    spool.StartPagePrinter.argtypes=[wt.HANDLE];spool.StartPagePrinter.restype=wt.BOOL
    spool.WritePrinter.argtypes=[wt.HANDLE,ctypes.c_void_p,wt.DWORD,ctypes.POINTER(wt.DWORD)];spool.WritePrinter.restype=wt.BOOL
    spool.EndPagePrinter.argtypes=[wt.HANDLE];spool.EndDocPrinter.argtypes=[wt.HANDLE];spool.ClosePrinter.argtypes=[wt.HANDLE]
    class DOC_INFO_1(ctypes.Structure):_fields_=[('pDocName',wt.LPWSTR),('pOutputFile',wt.LPWSTR),('pDatatype',wt.LPWSTR)]
    if not spool.OpenPrinterW(printer,ctypes.byref(handle),None):raise OSError(ctypes.get_last_error(),'Impressora nao acessivel')
    try:
        info=DOC_INFO_1(job_name,None,'RAW')
        if not spool.StartDocPrinterW(handle,1,ctypes.byref(info)):raise OSError(ctypes.get_last_error(),'Falha ao iniciar comanda')
        try:
            if not spool.StartPagePrinter(handle):raise OSError(ctypes.get_last_error(),'Falha ao iniciar pagina')
            try:
                written=wt.DWORD(0); buf=ctypes.create_string_buffer(raw)
                if not spool.WritePrinter(handle,buf,len(raw),ctypes.byref(written)) or written.value!=len(raw):raise OSError(ctypes.get_last_error(),'Falha ao enviar a comanda')
            finally:spool.EndPagePrinter(handle)
        finally:spool.EndDocPrinter(handle)
    finally:spool.ClosePrinter(handle)

def a4_print(printer, order, items):
    import tempfile
    lines=build_ticket(order,items,80,as_lines=True)
    # Remove comandos exclusivos da impressora térmica; o Windows formata o papel A4.
    path=None
    try:
        with tempfile.NamedTemporaryFile(mode='w',suffix='.json',prefix='menux-',encoding='utf-8',dir=str(HOME),delete=False) as f:
            json.dump({'lines':lines},f,ensure_ascii=False)
            path=f.name
        cmd=['powershell.exe','-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass',
             '-File',str(pathlib.Path(__file__).with_name('menux-imprimir-a4.ps1')),
             '-TicketPath',path,'-PrinterName',printer]
        process=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=45,
                              creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        if process.returncode:
            raise RuntimeError((process.stderr or process.stdout or 'Falha no driver de impressão A4').strip()[-500:])
    finally:
        if path:
            try:os.unlink(path)
            except OSError:pass

class Api(http.server.BaseHTTPRequestHandler):
    def log_message(self,fmt,*args): print(time.strftime('%H:%M:%S'),fmt%args)
    def headers_ok(self):
        return self.headers.get('Origin')==ORIGIN and secrets.compare_digest(self.headers.get('X-MENUX-Token',''),TOKEN)
    def respond(self,status,data):
        body=json.dumps(data,ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        if self.headers.get('Origin')==ORIGIN:
            self.send_header('Access-Control-Allow-Origin',ORIGIN)
            self.send_header('Vary','Origin')
        self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Cache-Control','no-store')
        self.send_header('Content-Length',str(len(body)))
        self.end_headers();self.wfile.write(body)
    def do_OPTIONS(self):
        if self.headers.get('Origin')!=ORIGIN:self.send_error(403);return
        self.send_response(204);self.send_header('Access-Control-Allow-Origin',ORIGIN);self.send_header('Access-Control-Allow-Methods','GET, POST, OPTIONS');self.send_header('Access-Control-Allow-Headers','X-MENUX-Token, Content-Type');self.send_header('Access-Control-Max-Age','600');self.end_headers()
    def do_GET(self):
        if not self.headers_ok():self.respond(403,{'error':'Origem ou chave invalida'});return
        if self.path=='/printers':
            try:self.respond(200,{'printers':installed_printers()})
            except Exception as e:self.respond(500,{'error':str(e)})
        else:self.respond(404,{'error':'Nao encontrado'})
    def do_POST(self):
        if not self.headers_ok():self.respond(403,{'error':'Origem ou chave invalida'});return
        if self.path!='/print':self.respond(404,{'error':'Nao encontrado'});return
        try:
            size=int(self.headers.get('Content-Length',0))
            if size<=0 or size>80000:raise ValueError('Pedido muito grande')
            payload=json.loads(self.rfile.read(size))
            printer=payload.get('printer','')
            if printer not in installed_printers():raise ValueError('Impressora nao instalada ou nao encontrada')
            order=payload.get('order',{});items=payload.get('items',[])
            if not isinstance(order,dict) or not isinstance(items,list) or not items:raise ValueError('Pedido sem produtos')
            rest=clean(order.get('restaurant_id')); oid=clean(order.get('id'))
            if len(rest)!=36 or len(oid)!=36:raise ValueError('Identificacao do pedido invalida')
            paper=str(payload.get('width',80))
            if paper not in ('58','80','A4'):raise ValueError('Papel invalido')
            with LOCK:
                if DATABASE.execute('SELECT 1 FROM prints WHERE restaurant=? AND order_id=?',(rest,oid)).fetchone():
                    self.respond(200,{'status':'ja_impresso'});return
                if paper=='A4':
                    a4_print(printer,order,items)
                else:
                    raw=build_ticket(order,items,int(paper))
                    raw_print(printer,raw,'MENUX pedido '+str(order.get('daily_number','')))
                DATABASE.execute('INSERT INTO prints(restaurant,order_id) VALUES (?,?)',(rest,oid)); DATABASE.commit()
            self.respond(200,{'status':'aceito_pelo_driver'})
        except Exception as e:
            self.respond(400,{'error':str(e)[:260]})

if __name__=='__main__':
    print('\n======================================')
    print(' MENUX IMPRESSOR WINDOWS - GRATUITO')
    print('======================================')
    print('Chave local (cole na aba Impressao da MENUX):\n')
    print(TOKEN)
    print('\nImpressao: termica ESC/POS 58/80 mm ou A4 via driver Windows.')
    print('A janela pode ficar oculta se instalado para iniciar com o Windows.')
    print('Para receber pedidos, o painel MENUX deve estar aberto no navegador.\n')
    try:http.server.ThreadingHTTPServer(('127.0.0.1',PORT),Api).serve_forever()
    except OSError as e:print('Porta ocupada ou erro de rede local:',e);input('Enter para sair...')
